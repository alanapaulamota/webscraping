package webscapping;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Boost2 {
	public static void main(String[] args) throws IOException {
		String url = "https://lists.boost.org/Archives/boost//2022/07/253297.php";
		Document doc = null;
		try {
			doc = Jsoup.connect(url).get();
		} catch (IOException e) {
			e.printStackTrace();
		}

		Element element = doc.select("body p").first();
		String frase = element.text();

		element.select("em").remove();
		frase = element.text();

		// Divide a frase em duas partes
		int index = frase.length() / 2;
		String nome = frase.substring(0, index - 5);
		String data = frase.substring(index - 2);

		System.out.println("Autor: " + nome);
		System.out.println("Date:" + data);

//		Elements contentElements = doc.select("body");
//		Map<String, String> boost = new HashMap<>();
//		for (Element element : contentElements) {
//			Elements postTextElements = element.getElementsByClass("headers");
//			if (postTextElements.size() == 1) {
//				boost.put(element.attr("id"), postTextElements.get(0).text());
//				
//			    element.select("a").remove();
//		        frase = element.text();
//			}
//		}

//	    String palavra = "hidden";
//	    Elements = element.replaceAll("\\b" + palavra + "\\b", "");

//		for (Map.Entry<String, String> b : boost.entrySet()) {
//			System.out.println(b.getKey() + " Autor e Data " + b.getValue());
//
//		}

//
//		Elements title = doc.select("title");
//		for (Element t : title) {
//			String texto = t.text();
//			System.out.println("Assunto: " + texto);
//		}
//
//		Elements corpo = doc.select("p");
//		for (Element p : corpo) {
//			String texto = p.text();
//			System.out.println("corpo do e-mail: " + texto);
//		}
//
//		Element lista = doc.select("ul").first();
//		Element item = lista.select("li").get(3);
//		String texto = item.text();
//		System.out.println("Respondente: " + texto);
//	}

//		Elements paragrafos = doc.select("p");
//		for (Element paragrafo : paragrafos) {
//			String texto = paragrafo.text().trim();
//			if (!texto.isEmpty()) {
//				System.out.println(texto);
//			}

//	        String variavel = "Date";
//	        Element inputElement = doc.select("input[name=" + variavel + "]").first();
//	        if (inputElement != null) {
//	            // Extrai o valor da variável
//	            String valor = inputElement.attr("value");
//	            System.out.println("O valor da variável " + variavel + " é " + valor);
//	        } else {
//	            System.out.println("A variável " + variavel + " não foi encontrada na página " + url);
//	        }
	}
}
