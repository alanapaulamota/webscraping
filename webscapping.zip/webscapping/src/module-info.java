/**
 * 
 */
/**
 * @author alanapaula
 *
 */
module webscapping {
	requires org.jsoup;
}